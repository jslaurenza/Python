                         THE LIVEWIRES PACKAGE 3.0 


Dependencies
------------
To install the livewires package, you must first install Python. To 
use the livewires package, you must first install pygame.


Installation
------------
Run the setup.bat file by double-clicking it. If you get a message that 
Python can't be found, you may need to update your PATH to include the 
folder in which you installed Python.


Testing
-------
Start the Python interpreter and type:

from livewires import games, color

If this line produces no errors, you've successfully installed the 
package. If you get an error that refers to pygame, you may not have 
successfully installed pygame. pygame is required to use livewires.

